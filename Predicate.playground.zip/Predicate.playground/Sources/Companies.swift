//
//  Copyright (c) KxCoding
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//
import Foundation

public class Company: NSObject {
    @objc public let rank: Int
    @objc public let name: String
    @objc public let revenue: Double

    init(rank: Int, name: String, revenue: Double) {
        self.rank = rank
        self.name = name
        self.revenue = revenue

        super.init()
    }

    public override var description: String {
        return "#\(rank): \(name)(\(revenue.formatted(.currency(code: "usd"))))"
    }

    public override var debugDescription: String {
        return "#\(rank): \(name)(\(revenue.formatted(.currency(code: "usd"))))"
    }
}

public let companies: NSArray = [
    Company(rank: 1, name: "Walmart", revenue: 500343.0),
    Company(rank: 2, name: "Exxon Mobil", revenue: 244363.0),
    Company(rank: 3, name: "Berkshire Hathaway", revenue: 242137.0),
    Company(rank: 4, name: "Apple", revenue: 229234.0),
    Company(rank: 5, name: "UnitedHealth Group", revenue: 201159.0),
    Company(rank: 6, name: "McKesson", revenue: 198533.0),
    Company(rank: 7, name: "CVS Health", revenue: 184765.0),
    Company(rank: 8, name: "Amazon.com", revenue: 177866.0),
    Company(rank: 9, name: "AT&T", revenue: 160546.0),
    Company(rank: 10, name: "General Motors", revenue: 157311.0),
    Company(rank: 11, name: "Ford Motor", revenue: 156776.0),
    Company(rank: 12, name: "AmerisourceBergen", revenue: 153144.0),
    Company(rank: 13, name: "Chevron", revenue: 134533.0),
    Company(rank: 14, name: "Cardinal Health", revenue: 129976.0),
    Company(rank: 15, name: "Costco", revenue: 129025.0),
    Company(rank: 16, name: "Verizon", revenue: 126034.0),
    Company(rank: 17, name: "Kroger", revenue: 122662.0),
    Company(rank: 18, name: "General Electric", revenue: 122274.0),
    Company(rank: 19, name: "Walgreens Boots Alliance", revenue: 118214.0),
    Company(rank: 20, name: "JPMorgan Chase", revenue: 113899.0),
    Company(rank: 21, name: "Fannie Mae", revenue: 112394.0),
    Company(rank: 22, name: "Alphabet", revenue: 110855.0),
    Company(rank: 23, name: "Home Depot", revenue: 100904.0),
    Company(rank: 24, name: "Bank of America Corp.", revenue: 100264.0),
    Company(rank: 25, name: "Express Scripts Holding", revenue: 100064.6),
    Company(rank: 26, name: "Wells Fargo", revenue: 97741.0),
    Company(rank: 27, name: "Boeing", revenue: 93392.0),
    Company(rank: 28, name: "Phillips 66", revenue: 91568.0),
    Company(rank: 29, name: "Anthem", revenue: 90039.4),
    Company(rank: 30, name: "Microsoft", revenue: 89950.0),
    Company(rank: 31, name: "Valero Energy", revenue: 88407.0),
    Company(rank: 32, name: "Citigroup", revenue: 87966.0),
    Company(rank: 33, name: "Comcast", revenue: 84526.0),
    Company(rank: 34, name: "IBM", revenue: 79139.0),
    Company(rank: 35, name: "Dell Technologies", revenue: 78660.0),
    Company(rank: 36, name: "State Farm Insurance Cos.", revenue: 78330.8),
    Company(rank: 37, name: "Johnson & Johnson", revenue: 76450.0),
    Company(rank: 38, name: "Freddie Mac", revenue: 74676.0),
    Company(rank: 39, name: "Target", revenue: 71879.0),
    Company(rank: 40, name: "Lowe’s", revenue: 68619.0),
    Company(rank: 41, name: "Marathon Petroleum", revenue: 67610.0),
    Company(rank: 42, name: "Procter & Gamble", revenue: 66217.0),
    Company(rank: 43, name: "MetLife", revenue: 66153.0),
    Company(rank: 44, name: "UPS", revenue: 65872.0),
    Company(rank: 45, name: "PepsiCo", revenue: 63525.0),
    Company(rank: 46, name: "Intel", revenue: 62761.0),
    Company(rank: 47, name: "DowDuPont", revenue: 62683.0),
    Company(rank: 48, name: "Archer Daniels Midland", revenue: 60828.0),
    Company(rank: 49, name: "Aetna", revenue: 60535.0),
    Company(rank: 50, name: "FedEx", revenue: 60319.0),
    Company(rank: 51, name: "United Technologies", revenue: 59837.0),
    Company(rank: 52, name: "Prudential Financial", revenue: 59689.0),
    Company(rank: 53, name: "Albertsons Cos.", revenue: 59678.2),
    Company(rank: 54, name: "Sysco", revenue: 55371.1),
    Company(rank: 55, name: "Disney", revenue: 55137.0),
    Company(rank: 56, name: "Humana", revenue: 53767.0),
    Company(rank: 57, name: "Pfizer", revenue: 52546.0),
    Company(rank: 58, name: "HP", revenue: 52056.0),
    Company(rank: 59, name: "Lockheed Martin", revenue: 51048.0),
    Company(rank: 60, name: "AIG", revenue: 49520.0),
    Company(rank: 61, name: "Centene", revenue: 48572.0),
    Company(rank: 62, name: "Cisco Systems", revenue: 48005.0),
    Company(rank: 63, name: "HCA Healthcare", revenue: 47653.0),
    Company(rank: 64, name: "Energy Transfer Equity", revenue: 47487.0),
    Company(rank: 65, name: "Caterpillar", revenue: 45462.0),
    Company(rank: 66, name: "Nationwide", revenue: 43939.9),
    Company(rank: 67, name: "Morgan Stanley", revenue: 43642.0),
    Company(rank: 68, name: "Liberty Mutual Insurance Group", revenue: 42687.0),
    Company(rank: 69, name: "New York Life Insurance", revenue: 42296.0),
    Company(rank: 70, name: "Goldman Sachs Group", revenue: 42254.0),
    Company(rank: 71, name: "American Airlines Group", revenue: 42207.0),
    Company(rank: 72, name: "Best Buy", revenue: 42151.0),
    Company(rank: 73, name: "Cigna", revenue: 41616.0),
    Company(rank: 74, name: "Charter Communications", revenue: 41581.0),
    Company(rank: 75, name: "Delta Air Lines", revenue: 41244.0),
    Company(rank: 76, name: "Facebook", revenue: 40653.0),
    Company(rank: 77, name: "Honeywell International", revenue: 40534.0),
    Company(rank: 78, name: "Merck", revenue: 40122.0),
    Company(rank: 79, name: "Allstate", revenue: 38524.0),
    Company(rank: 80, name: "Tyson Foods", revenue: 38260.0),
    Company(rank: 81, name: "United Continental Holdings", revenue: 37736.0),
    Company(rank: 82, name: "Oracle", revenue: 37728.0),
    Company(rank: 83, name: "Tech Data", revenue: 36775.0),
    Company(rank: 84, name: "TIAA", revenue: 36025.3),
    Company(rank: 85, name: "TJX", revenue: 35864.7),
    Company(rank: 86, name: "American Express", revenue: 35583.0),
    Company(rank: 87, name: "Coca-Cola", revenue: 35410.0),
    Company(rank: 88, name: "Publix Super Markets", revenue: 34836.8),
    Company(rank: 89, name: "Nike", revenue: 34350.0),
    Company(rank: 90, name: "Andeavor", revenue: 34204.0),
    Company(rank: 91, name: "World Fuel Services", revenue: 33695.5),
    Company(rank: 92, name: "Exelon", revenue: 33531.0),
    Company(rank: 93, name: "Massachusetts Mutual Life Insurance", revenue: 33495.4),
    Company(rank: 94, name: "Rite Aid", revenue: 32845.1),
    Company(rank: 95, name: "ConocoPhillips", revenue: 32584.0),
    Company(rank: 96, name: "CHS", revenue: 31934.8),
    Company(rank: 97, name: "3M", revenue: 31657.0),
    Company(rank: 98, name: "Time Warner", revenue: 31271.0),
    Company(rank: 99, name: "General Dynamics", revenue: 30973.0),
    Company(rank: 100, name: "0USAA", revenue: 30015.8)
]
